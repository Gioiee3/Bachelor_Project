#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <sys/time.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"
#include "freertos/ringbuf.h"
#include "freertos/semphr.h"

#include "nvs_flash.h"

#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_smartconfig.h"
#include "mqtt_client.h"
#include "esp_spiffs.h"
#include "esp_http_client.h"
#include "esp_attr.h"
#include "esp_http_server.h"

#include "esp_err.h"
#include "esp_event.h"
#include "esp_system.h"
#include "esp_vfs.h"
#include "esp_sntp.h"

#include "driver/gpio.h"
#include "driver/uart.h"
#include "driver/spi_master.h"

#include "protocol_examples_common.h"

#include "st7789.h"
#include "fontx.h"
#include "bmpfile.h"
#include "decode_jpeg.h"
#include "decode_png.h"
#include "pngle.h"

#include "soc/soc_caps.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"

#include "sx1278.h"
// #include "uart_user.h"

#include "common.h"
#include "mqtt.h"
#include "smartcfg.h"
#include "wifi_sta.h"
#include "wifi_ap.h"
#include "webserver.h"
#include "button.h"

#define EXAMPLE_ADC1_CHAN1          ADC_CHANNEL_6
#define EXAMPLE_ADC_ATTEN           ADC_ATTEN_DB_11

static const char *TAG = "Main";
void l_task(void *param);
uint8_t rx[20];

extern EventGroupHandle_t sx1278_evt_group;
extern int count;
extern int flag_TFT;
extern uint8_t state;
extern sx1278_node_slot_t Node_Data[3];
int count_past = 0;
int connect_time = 0;

static int adc_raw[2][10] = {0};
static int voltage[2][10] = {0};
char ssid[50] = {0};
char pwd[50] = {0};

#ifndef INET6_ADDRSTRLEN
#define INET6_ADDRSTRLEN 48
#endif

static void initialize_sntp(void);

#ifdef CONFIG_SNTP_TIME_SYNC_METHOD_CUSTOM
void sntp_sync_time(struct timeval *tv)
{
   settimeofday(tv, NULL);
   ESP_LOGI(TAG, "Time is synchronized from custom code");
   sntp_set_sync_status(SNTP_SYNC_STATUS_COMPLETED);
}
#endif

void time_sync_notification_cb(struct timeval *tv)
{
    ESP_LOGI(TAG, "Notification of a time synchronization event");
}
//cấu hình cho SNTP
static void initialize_sntp(void)
{
    ESP_LOGI(TAG, "Initializing SNTP");
    esp_sntp_setoperatingmode(ESP_SNTP_OPMODE_POLL);
	
#if LWIP_DHCP_GET_NTP_SRV && SNTP_MAX_SERVERS > 1
    esp_sntp_setservername(1, "pool.ntp.org");

#if LWIP_IPV6 && SNTP_MAX_SERVERS > 2          // statically assigned IPv6 address is also possible
    ip_addr_t ip6;
    if (ipaddr_aton("2a01:3f7::1", &ip6)) {    // ipv6 ntp source "ntp.netnod.se"
        esp_sntp_setserver(2, &ip6);
    }
#endif  /* LWIP_IPV6 */
#else   /* LWIP_DHCP_GET_NTP_SRV && (SNTP_MAX_SERVERS > 1) */
    	// otherwise, use DNS address from a pool
    esp_sntp_setservername(0, "pool.ntp.org");
    esp_sntp_setservername(1, "pool.ntp.org");     // set the secondary NTP server (will be used only if SNTP_MAX_SERVERS > 1)
#endif

    // sntp_set_time_sync_notification_cb(time_sync_notification_cb);
#ifdef CONFIG_SNTP_TIME_SYNC_METHOD_SMOOTH
    sntp_set_sync_mode(SNTP_SYNC_MODE_SMOOTH);
#endif
    esp_sntp_init();
    ESP_LOGI(TAG, "List of configured NTP servers:");
    for (uint8_t i = 0; i < SNTP_MAX_SERVERS; ++i){
        if (esp_sntp_getservername(i)){
            ESP_LOGI(TAG, "server %d: %s", i, esp_sntp_getservername(i));
        } else {
            // we have either IPv4 or IPv6 address, let's print it
            char buff[INET6_ADDRSTRLEN];
            ip_addr_t const *ip = esp_sntp_getserver(i);
            if (ipaddr_ntoa_r(ip, buff, INET6_ADDRSTRLEN) != NULL)
                ESP_LOGI(TAG, "server %d: %s", i, buff);
        }
    }
}

static bool example_adc_calibration_init(adc_unit_t unit, adc_atten_t atten, adc_cali_handle_t *out_handle)
{
    adc_cali_handle_t handle = NULL;
    esp_err_t ret = ESP_FAIL;
    bool calibrated = false;
#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
    if (!calibrated) {
        ESP_LOGI(TAG, "calibration scheme version is %s", "Curve Fitting");
        adc_cali_curve_fitting_config_t cali_config = {
            .unit_id = unit,
            .atten = atten,
            .bitwidth = ADC_BITWIDTH_DEFAULT,
        };
        ret = adc_cali_create_scheme_curve_fitting(&cali_config, &handle);
        if (ret == ESP_OK) {
            calibrated = true;
        }
    }
#endif

#if ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
    if (!calibrated) {
        ESP_LOGI(TAG, "calibration scheme version is %s", "Line Fitting");
        adc_cali_line_fitting_config_t cali_config = {
            .unit_id = unit,
            .atten = atten,
            .bitwidth = ADC_BITWIDTH_DEFAULT,
        };
        ret = adc_cali_create_scheme_line_fitting(&cali_config, &handle);
        if (ret == ESP_OK) {
            calibrated = true;
        }
    }
#endif

    *out_handle = handle;
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "Calibration Success");
    } else if (ret == ESP_ERR_NOT_SUPPORTED || !calibrated) {
        ESP_LOGW(TAG, "eFuse not burnt, skip software calibration");
    } else {
        ESP_LOGE(TAG, "Invalid arg or no memory");
    }

    return calibrated;
}

static void SPIFFS_Directory(char * path) {
	DIR* dir = opendir(path);
	assert(dir != NULL);
	while (true) {
		struct dirent*pe = readdir(dir);
		if (!pe) break;
		ESP_LOGI(__FUNCTION__,"d_name=%s d_ino=%d d_type=%x", pe->d_name,pe->d_ino, pe->d_type);
	}
	closedir(dir);
}

// You have to set these CONFIG value using menuconfig.
#if 0
#define CONFIG_WIDTH  240
#define CONFIG_HEIGHT 240
#define CONFIG_MOSI_GPIO 23
#define CONFIG_SCLK_GPIO 18
#define CONFIG_CS_GPIO -1
#define CONFIG_DC_GPIO 19
#define CONFIG_RESET_GPIO 15
#define CONFIG_BL_GPIO -1
#endif

static TickType_t PNGTest(TFT_t * dev, char * file, int width, int height) {
	TickType_t startTick, endTick, diffTick;
	startTick = xTaskGetTickCount();

	lcdSetFontDirection(dev, 0);
	lcdFillScreen(dev, BLACK);

	// open PNG file
	FILE* fp = fopen(file, "rb");
	if (fp == NULL) {
		ESP_LOGW(__FUNCTION__, "File not found [%s]", file);
		return 0;
	}

	char buf[1024];
	size_t remain = 0;
	int len;

	pngle_t *pngle = pngle_new(width, height);

	pngle_set_init_callback(pngle, png_init);
	pngle_set_draw_callback(pngle, png_draw);
	pngle_set_done_callback(pngle, png_finish);

	double display_gamma = 2.2;
	pngle_set_display_gamma(pngle, display_gamma);


	while (!feof(fp)) {
		if (remain >= sizeof(buf)) {
			ESP_LOGE(__FUNCTION__, "Buffer exceeded");
			while(1) vTaskDelay(1);
		}

		len = fread(buf + remain, 1, sizeof(buf) - remain, fp);
		if (len <= 0) {
			//printf("EOF\n");
			break;
		}

		int fed = pngle_feed(pngle, buf, remain + len);
		if (fed < 0) {
			ESP_LOGE(__FUNCTION__, "ERROR; %s", pngle_error(pngle));
			while(1) vTaskDelay(1);
		}

		remain = remain + len - fed;
		if (remain > 0) memmove(buf, buf + fed, remain);
	}

	fclose(fp);

	uint16_t _width = width;
	uint16_t _cols = 0;
	if (width > pngle->imageWidth) {
		_width = pngle->imageWidth;
		_cols = (width - pngle->imageWidth) / 2;
	}
	ESP_LOGD(__FUNCTION__, "_width=%d _cols=%d", _width, _cols);

	uint16_t _height = height;
	uint16_t _rows = 0;
	if (height > pngle->imageHeight) {
			_height = pngle->imageHeight;
			_rows = (height - pngle->imageHeight) / 2;
	}
	ESP_LOGD(__FUNCTION__, "_height=%d _rows=%d", _height, _rows);
	uint16_t *colors = (uint16_t*)malloc(sizeof(uint16_t) * _width);

#if 0
	for(int y = 0; y < _height; y++){
		for(int x = 0;x < _width; x++){
			pixel_png pixel = pngle->pixels[y][x];
			uint16_t color = rgb565(pixel.red, pixel.green, pixel.blue);
			lcdDrawPixel(dev, x+_cols, y+_rows, color);
		}
	}
#endif

	for(int y = 0; y < _height; y++){
		for(int x = 0;x < _width; x++){
			//pixel_png pixel = pngle->pixels[y][x];
			//colors[x] = rgb565(pixel.red, pixel.green, pixel.blue);
			colors[x] = pngle->pixels[y][x];
		}
		lcdDrawMultiPixels(dev, _cols, y+_rows, _width, colors);
		vTaskDelay(1);
	}
	lcdDrawFinish(dev);
	free(colors);
	pngle_destroy(pngle, width, height);

	endTick = xTaskGetTickCount();
	diffTick = endTick - startTick;
	ESP_LOGI(__FUNCTION__, "elapsed time[ms]:%"PRIu32,diffTick*portTICK_PERIOD_MS);
	return diffTick;
}

static void TFT_Clear(TFT_t * dev)
{
	lcdDrawFillRect(dev, 25, 11, 74, 31, WHITE); // clear BAT 
	lcdDrawFillRect(dev, 61 , 66, 209, 103, WHITE); // clear add
	lcdDrawFillRect(dev, 14, 157, 86, 195, WHITE); // clear speed
	lcdDrawFillRect(dev, 163 , 157, 209, 213, WHITE); // clear direction
	lcdDrawFillRect(dev, 20 , 192, 209, 213, WHITE); // clear level
	lcdDrawFillRect(dev, 14, 271, 229, 308, WHITE);    // clear temp, humid

	lcdDrawFinish(dev);
}

void ST7789(void *pvParameters){
	// set font file
	FontxFile fx16G[2];
	FontxFile fx24G[2];
	FontxFile fx32G[2];
	FontxFile fx32L[2];
	InitFontx(fx16G,"/spiffs/ILGH16XB.FNT",""); // 8x16Dot Gothic
	InitFontx(fx24G,"/spiffs/ILGH24XB.FNT",""); // 12x24Dot Gothic
	InitFontx(fx32G,"/spiffs/ILGH32XB.FNT",""); // 16x32Dot Gothic
	InitFontx(fx32L,"/spiffs/LATIN32B.FNT",""); // 16x32Dot Latin

	FontxFile fx16M[2];
	FontxFile fx24M[2];
	FontxFile fx32M[2];
	InitFontx(fx16M,"/spiffs/ILMH16XB.FNT",""); // 8x16Dot Mincyo
	InitFontx(fx24M,"/spiffs/ILMH24XB.FNT",""); // 12x24Dot Mincyo
	InitFontx(fx32M,"/spiffs/ILMH32XB.FNT",""); // 16x32Dot Mincyo
	
	TFT_t dev;

	// Change SPI Clock Frequency
	//spi_clock_speed(40000000); // 40MHz
	//spi_clock_speed(60000000); // 60MHz

	spi_master_init(&dev, CONFIG_MOSI_GPIO, CONFIG_SCLK_GPIO, CONFIG_CS_GPIO, CONFIG_DC_GPIO, CONFIG_RESET_GPIO, CONFIG_BL_GPIO);
	lcdInit(&dev, CONFIG_WIDTH, CONFIG_HEIGHT, CONFIG_OFFSETX, CONFIG_OFFSETY);

#if CONFIG_INVERSION
	//ESP_LOGI(TAG, "Enable Display Inversion");
	//lcdInversionOn(&dev);
	lcdInversionOff(&dev);
#endif

	time_t now;
    struct tm timeinfo;
	int day = 0, month = 0, year = 0, hour = 0, min = 0;
	int k = 161;
    time(&now);
    localtime_r(&now, &timeinfo);

	lcdSetFontDirection(&dev, 0);
	lcdFillScreen(&dev, WHITE);
	lcdDrawFinish(&dev);
	lcdDrawString(&dev, fx32G, 19, 169,(uint8_t *) "Connecting...", MEDICI_BLUE);
    // Is time set? If not, tm_year will be (1970 - 1900).
    if (timeinfo.tm_year < (2016 - 1900)) 
    {
        #if LWIP_DHCP_GET_NTP_SRV
            esp_sntp_servermode_dhcp(1);      // accept NTP offers from DHCP server, if any
        #endif
        initialize_sntp();
        int retry = 0;
        const int retry_count = 5;
        while (sntp_get_sync_status() == SNTP_SYNC_STATUS_RESET && ++retry < retry_count) {
            ESP_LOGI(TAG, "Waiting for system time to be set... (%d/%d)", retry, retry_count);
            vTaskDelay(2000 / portTICK_PERIOD_MS);
        }
        time(&now);
    }
	#ifdef CONFIG_SNTP_TIME_SYNC_METHOD_SMOOTH
		else {
			// add 500 ms error to the current system time.
			// Only to demonstrate a work of adjusting method!
			{
				ESP_LOGI(TAG, "Add a error for test adjtime");
				struct timeval tv_now;
				gettimeofday(&tv_now, NULL);
				int64_t cpu_time = (int64_t)tv_now.tv_sec * 1000000L + (int64_t)tv_now.tv_usec;
				int64_t error_time = cpu_time + 500 * 1000L;
				struct timeval tv_error = { .tv_sec = error_time / 1000000L, .tv_usec = error_time % 1000000L };
				settimeofday(&tv_error, NULL);
			}

			ESP_LOGI(TAG, "Time was set, now just adjusting it. Use SMOOTH SYNC method.");
			obtain_time();
			// update 'now' variable with current time
			time(&now);
		}
	#endif

    setenv("TZ", "ICT-7", 1);
    tzset();
	char file[32];
	
	strcpy(file, "/spiffs/esp_logo.png");
	PNGTest(&dev, file, CONFIG_WIDTH, CONFIG_HEIGHT);

    xTaskCreate(&sx1278_TASK, "SX1278", 4096, NULL, 8, NULL);	

	time(&now);
	localtime_r(&now, &timeinfo);
    char strftime_buf[64];
	uint8_t ascii[30];		
	strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
	memset(ascii, '\0', sizeof(ascii));
	memcpy(ascii, strftime_buf , 3);
	// memcpy((uint8_t *) day, (uint8_t *) strftime_buf + 8, 2);     
	lcdDrawString(&dev, fx16M, 239 - k, 28, ascii, COLOR_1);
	sprintf((char* )ascii, " %d/%d/%d", timeinfo.tm_mday, timeinfo.tm_mon + 1, timeinfo.tm_year + 1900);
	lcdDrawString(&dev, fx16M, 239 - k + 21 , 28, ascii, COLOR_1); // display date
	lcdDrawFinish(&dev);
	
	// lcdDrawFillRect(&dev, 199 , 67, 54, 31, WHITE); // clear time
	lcdDrawFillRect(&dev, 54 , 31, 199, 67, WHITE); // clear time
	sprintf((char*)ascii, "%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min); 
	lcdDrawString(&dev, fx32M, 81, 64, ascii, COLOR_1); // display time
	lcdDrawFinish(&dev);

	day   = timeinfo.tm_mday;
	month = timeinfo.tm_mon;
	year  = timeinfo.tm_year;
	hour  = timeinfo.tm_hour;
	min   = timeinfo.tm_min;
	// sec   = timeinfo.tm_sec;

	lcdDrawString(&dev, fx16G, 25 , 28,(uint8_t *) Node_Data[0].battery , BLACK);
	lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 1", COLOR_1);

	// sprintf((char*)ascii, "%.1f", 4.15 * 3.6);
	lcdDrawString(&dev, fx32G, 18, 192, (uint8_t *) Node_Data[0].wind_speed, RED);
	lcdDrawString(&dev, fx16G, 88, 188, (uint8_t *)"m/s", RED);

	sprintf((char*)ascii, "Level:%d", Node_Data[0].wind_level);
	lcdDrawString(&dev, fx16G, 31, 211, ascii, RED);

	lcdDrawString(&dev, fx32G, 166 , 192, (uint8_t * )Node_Data[0].wind_direction_chr, RED);
	// sprintf((char*)ascii, "%d", 120); 
	// lcdDrawString(&dev, fx16G, 71 , 108, ascii, RED); // display angle

	// sprintf((char*)ascii, "%.1f", 24.15);
	lcdDrawString(&dev, fx32G, 18, 305, (uint8_t*) Node_Data[0].temp_lm35, RED);

	lcdDrawString(&dev, fx32M, 85, 287, (uint8_t *)".", RED);
	lcdDrawString(&dev, fx32G, 95, 305, (uint8_t* )"C", RED);

	// sprintf((char*)ascii, "%.1f%c", 90.15, 0x25);
	lcdDrawString(&dev, fx32G, 159 , 305, (uint8_t *)Node_Data[0].humid_aht, RED);
	lcdDrawFinish(&dev);
	while(1) 
	{	
		if ((timeinfo.tm_year < (2016 - 1900))&&(connect_time == 1)) 
		{
			#if LWIP_DHCP_GET_NTP_SRV
				esp_sntp_servermode_dhcp(1);      // accept NTP offers from DHCP server, if any
			#endif
			initialize_sntp();
			int retry = 0;
			const int retry_count = 5;
			while (sntp_get_sync_status() == SNTP_SYNC_STATUS_RESET && ++retry < retry_count) {
				ESP_LOGI(TAG, "Waiting for system time to be set... (%d/%d)", retry, retry_count);
				vTaskDelay(2000 / portTICK_PERIOD_MS);
			}
			time(&now);
			connect_time = 0;
		}	
		time(&now);
		localtime_r(&now, &timeinfo);

		if ((day != timeinfo.tm_mday)||(month != timeinfo.tm_mon)||(year != timeinfo.tm_year))
		{
			// lcdDrawFillRect(&dev, 199 , 31, 76, 11, WHITE); // clear date
			lcdDrawFillRect(&dev, 76 , 11, 199, 31, WHITE); // clear date
			strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);
			memset(ascii, '\0', sizeof(ascii));
			memcpy(ascii, strftime_buf , 3);
			// memcpy((uint8_t *) day, (uint8_t *) strftime_buf + 8, 2);     
			lcdDrawString(&dev, fx16M,239 - k, 28, ascii, COLOR_1);
			sprintf((char* )ascii, " %d/%d/%d", timeinfo.tm_mday, timeinfo.tm_mon + 1, timeinfo.tm_year + 1900);
			lcdDrawString(&dev, fx16M,239 - k + 21 , 28, ascii, COLOR_1); // display date
			// lcdDrawFinish(&dev);
		}

		if ((hour != timeinfo.tm_hour)||(min != timeinfo.tm_min))
		{
			// lcdDrawFillRect(&dev, 199 , 67, 54, 31, WHITE); // clear time
			lcdDrawFillRect(&dev, 54 , 31, 199, 67, WHITE); // clear time
			sprintf((char*)ascii, "%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min); 
			lcdDrawString(&dev, fx32M, 81, 64, ascii, COLOR_1); // display time
			// lcdDrawFinish(&dev);
		}

		if (count != count_past)
		{
			TFT_Clear(&dev);
			lcdDrawString(&dev, fx16G, 25 , 28,(uint8_t *) Node_Data[count].battery , BLACK); // display BAT

			if (count == 0) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 1", COLOR_1);
			if (count == 1) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 2", COLOR_1);
			if (count == 2) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 3", COLOR_1);
			// sprintf((char*)ascii, "%.1f", 4.15 * 3.6);
			lcdDrawString(&dev, fx32G, 18 , 192, (uint8_t *) Node_Data[count].wind_speed, RED); // display speed
			// lcdDrawString(&dev, fx16G, 151 , 131, (uint8_t *)"KMPH", RED);

			sprintf((char*)ascii, "Level:%d", Node_Data[count].wind_level);
			lcdDrawString(&dev, fx16G, 31, 211, ascii, RED); // display level
			
			lcdDrawString(&dev, fx32G, 166 , 192, (uint8_t * )Node_Data[count].wind_direction_chr, RED); // display direction
			// sprintf((char*)ascii, "%d", 120); 
			// lcdDrawString(&dev, fx16G, 71 , 108, ascii, RED); // display angle

			lcdDrawString(&dev, fx32G, 18, 305,(uint8_t*) Node_Data[count].temp_lm35, RED); // display temp
			lcdDrawString(&dev, fx32M, 85, 287, (uint8_t *)".", RED);
			lcdDrawString(&dev, fx32G, 95, 305, (uint8_t* )"C", RED);

			// sprintf((char*)ascii, "%.1f%c", 90.15, 0x25);
			lcdDrawString(&dev, fx32G, 159 , 305, (uint8_t *)Node_Data[count].humid_aht, RED); // display humid
			lcdDrawFinish(&dev);
			count_past = count;
		}

		if (flag_TFT == 1) 
		{
			TFT_Clear(&dev);
			lcdDrawString(&dev, fx16G, 25 , 28,(uint8_t *) Node_Data[count].battery , BLACK); // display BAT

			if (count == 0) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 1", COLOR_1);
			if (count == 1) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 2", COLOR_1);
			if (count == 2) lcdDrawString(&dev, fx32L, 75, 100,(uint8_t *) "NODE 3", COLOR_1);

			lcdDrawString(&dev, fx32G, 18 , 192, (uint8_t *) Node_Data[count].wind_speed, RED); // display speed

			sprintf((char*)ascii, "Level:%d", Node_Data[count].wind_level);
			lcdDrawString(&dev, fx16G, 31 , 211, ascii, RED); // display level
			
			lcdDrawString(&dev, fx32G, 166 , 192, (uint8_t * )Node_Data[count].wind_direction_chr, RED); // display direction
			// sprintf((char*)ascii, "%d", 120); 
			// lcdDrawString(&dev, fx16G, 71 , 108, ascii, RED); // display angle

			lcdDrawString(&dev, fx32G, 18, 305, (uint8_t *) Node_Data[count].temp_lm35, RED); // display temp
			lcdDrawString(&dev, fx32M, 85, 287, (uint8_t *)".", RED);
			lcdDrawString(&dev, fx32G, 95, 305, (uint8_t* )"C", RED);

			lcdDrawString(&dev, fx32G, 159 , 305, (uint8_t *)Node_Data[count].humid_aht, RED); // display humid
			lcdDrawFinish(&dev);
			flag_TFT = 0;
		}

		if (state == 0) 
		{
			lcdDisplayOff(&dev);
			lcdBacklightOff(&dev);
		}
		else
		{
			lcdDisplayOn(&dev);
			lcdBacklightOn(&dev);
		}
		// gpio_set_level(l, state);
		day   = timeinfo.tm_mday;
		month = timeinfo.tm_mon;
		year  = timeinfo.tm_year;
		hour  = timeinfo.tm_hour;
		min   = timeinfo.tm_min;
		// sec   = timeinfo.tm_sec;
		vTaskDelay(100 / portTICK_PERIOD_MS);
	}
}

void app_main(void)
{
	ESP_LOGI(TAG, "Initializing SPIFFS");

	esp_vfs_spiffs_conf_t conf = {
		.base_path = "/spiffs",
		.partition_label = NULL,
		.max_files = 12,
		.format_if_mount_failed =true
	};

	esp_err_t ret = esp_vfs_spiffs_register(&conf);
	if (ret != ESP_OK) {
		if (ret == ESP_FAIL) {
			ESP_LOGE(TAG, "Failed to mount or format filesystem");
		} else if (ret == ESP_ERR_NOT_FOUND) {
			ESP_LOGE(TAG, "Failed to find SPIFFS partition");
		} else {
			ESP_LOGE(TAG, "Failed to initialize SPIFFS (%s)",esp_err_to_name(ret));
		}
		return;
	}

	size_t total = 0, used = 0;
	ret = esp_spiffs_info(NULL, &total, &used);
	if (ret != ESP_OK)	ESP_LOGE(TAG,"Failed to get SPIFFS partition information (%s)",esp_err_to_name(ret));
	else 				ESP_LOGI(TAG,"Partition size: total: %d, used: %d", total, used);
	SPIFFS_Directory("/spiffs/");

	esp_err_t err;
    ESP_LOGI(TAG, "Initializing...");
    err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

	sx1278_gpio_init();
    sx1278_spi_init();
    sx1278_init();

	wifi_init();
    sprintf(ssid, "Laptop"); //"TP-Link_5AB6"
    sprintf(pwd, "888888888"); //"11173793"
    wifi_config_t wifi_config;
    bzero(&wifi_config, sizeof(wifi_config_t));
    memcpy(wifi_config.sta.ssid, ssid, strlen(ssid));
    memcpy(wifi_config.sta.password, pwd, strlen(pwd));    
    wifi_sta(wifi_config, WIFI_MODE_STA);

    xTaskCreate(&button_task, "button_task", 2048, NULL, 7, NULL);
	xTaskCreate(ST7789, "ST7789", 1024*6, NULL, 6, NULL);
    // xTaskCreate(&l_task, "l_task", 2048, NULL, 4, NULL);
    while (1)
    {
		// sprintf(data,"{\"Nhietdo\":0xCAAC}");
		// sprintf(data,"{\"node %d\": %d}", get_random_value(5, 10), get_random_value(15,20));
		// esp_mqtt_client_publish(client, TOPIC , data, 0, 1, 0);		
        // // sx1278_recv_data(rx, &nByteRx, &rssi, &snr, false);
        vTaskDelay(1000/portTICK_PERIOD_MS);
        // ESP_LOGI(TAG, "%s", rx);
    }	
}

void l_task(void *param)
{
		//-------------ADC1 Init---------------//
    adc_oneshot_unit_handle_t adc1_handle;
    adc_oneshot_unit_init_cfg_t init_config1 = { .unit_id = ADC_UNIT_1, };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config1, &adc1_handle));

    //-------------ADC1 Config---------------//
    adc_oneshot_chan_cfg_t config = {
        .bitwidth = ADC_BITWIDTH_DEFAULT,
        .atten = EXAMPLE_ADC_ATTEN,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, EXAMPLE_ADC1_CHAN1, &config));

    //-------------ADC1 Calibration Init---------------//
    adc_cali_handle_t adc1_cali_handle = NULL;
    bool do_calibration1 = example_adc_calibration_init(ADC_UNIT_1, EXAMPLE_ADC_ATTEN, &adc1_cali_handle);
    while(1)
    {
		ESP_ERROR_CHECK(adc_oneshot_read(adc1_handle, EXAMPLE_ADC1_CHAN1, &adc_raw[0][1]));
        ESP_LOGI(TAG, "ADC%d Channel[%d] Raw Data: %d", ADC_UNIT_1 + 1, EXAMPLE_ADC1_CHAN1, adc_raw[0][1]);
        if (do_calibration1) 
		{
            ESP_ERROR_CHECK(adc_cali_raw_to_voltage(adc1_cali_handle, adc_raw[0][1], &voltage[0][1]));
            ESP_LOGI(TAG, "ADC%d Channel[%d] Cali Voltage: %d mV", ADC_UNIT_1 + 1, EXAMPLE_ADC1_CHAN1, voltage[0][1]);
        }
        gpio_set_level(l, 1);
        vTaskDelay(1000/portTICK_PERIOD_MS);
        gpio_set_level(l, 0);
        vTaskDelay(1000/portTICK_PERIOD_MS);
    }
}