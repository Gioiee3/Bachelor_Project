/**
 * @file button.c
 * @author Kyuubi0323 (khoi.nv202647@sis.hust.edu.vn)
 * @brief 
 * @version 0.1
 * @date 2023-12-23
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/queue.h"
#include "freertos/ringbuf.h"
#include "freertos/semphr.h"

#include "nvs_flash.h"

#include "esp_mac.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_smartconfig.h"
#include "mqtt_client.h"
#include "esp_spiffs.h"
#include "esp_http_client.h"
#include "esp_attr.h"
#include "esp_http_server.h"

#include "driver/gpio.h"
#include "driver/uart.h"
#include "driver/spi_master.h"

// #include "cjson/cJSON.h"
// #include "cjson/cJSON_Utils.h"
// #include "mqtt/mqtt.h"
// #include "smartcfg/smartcfg.h"
// #include "wifi/wifi_sta.h"
// #include "wifi/wifi_ap.h"
// #include "cfg/common.h"
#include "button.h"
// #include "interface/led.h"
// #include "fota/fota.h"
// #include "mesh/ble_mesh_user.h"
// #include "spiffs/spiffs.h"
// #include "web_server/web_server.h"

static const char *TAG = "BUTTON";
// extern RTC_NOINIT_ATTR int gateway_mode_flag;
uint32_t current_Time = 0, previous_Time = 0;
int count = 0;
uint8_t state = 1;

void button_init(void)
{
    // esp_rom_gpio_pad_select_gpio(l);
    // gpio_reset_pin(l);
    // gpio_set_direction(l, GPIO_MODE_OUTPUT);

    esp_rom_gpio_pad_select_gpio(LED_TFT_PIN);
    gpio_reset_pin(LED_TFT_PIN);
    gpio_set_direction(LED_TFT_PIN, GPIO_MODE_OUTPUT);

    gpio_config_t io1_config = {
        .pin_bit_mask = BIT64(SW1),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io1_config);

    gpio_config_t io2_config = {
        .pin_bit_mask = BIT64(SW_LED),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io2_config);

    gpio_config_t io3_config = {
        .pin_bit_mask = BIT64(SW3),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io3_config);
}

void button_task(void *param)
{
    // int io_num;
    button_t button1 = {
        .pin = SW1,
        .time_down = 0,
        .time_up = 0,
        .deltaT = 0,
        .click_cnt = 0,
        .time_stamp = 0,
    };
    button_t button_led = {
        .pin = SW_LED,
        .time_down = 0,
        .time_up = 0,
        .deltaT = 0,
        .click_cnt = 0,
        .time_stamp = 0,
    };
    button_t button3 = {
        .pin = SW3,
        .time_down = 0,
        .time_up = 0,
        .deltaT = 0,
        .click_cnt = 0,
        .time_stamp = 0,
    };
    button_init();
    while (1)
    {
        if (gpio_get_level(SW1) == BUTTON_TRIGGER)
        {
            if (button1.time_up == 0)    button1.time_up = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
            else                         button1.deltaT = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button1.time_up;
        }
        else if (gpio_get_level(SW1) == BUTTON_NOT_TRIGGER && button1.time_up != 0 && button1.deltaT > TIME_CLICK_MIN)
            {
                count++;
                if (count > 2) count = 0;
                ESP_LOGI(TAG, "STATE SW1");
                ESP_LOGI(TAG, "DeltaT: %.0ld", button1.deltaT);
                button1.time_up = 0;
                button1.time_down = 0;
                button1.deltaT = 0;            
            }
            else // if (gpio_get_level(SW1) == BUTTON_NOT_TRIGGER && (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button.time_stamp > TIME_RESET && button.time_stamp != 0)
            {
                button1.time_up = 0;
                button1.time_down = 0;
                button1.deltaT = 0;
                button1.click_cnt = 0;
                button1.time_stamp = 0;
            }

        if (gpio_get_level(SW3) == BUTTON_TRIGGER)
        {
            if (button3.time_up == 0)   button3.time_up = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
            else                        button3.deltaT = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button3.time_up;
        }
        else if (gpio_get_level(SW3) == BUTTON_NOT_TRIGGER && button3.time_up != 0 && button3.deltaT > TIME_CLICK_MIN)
            {
                if (count > 0) count--;
                else count = 2;
                ESP_LOGI(TAG, "nut nhan sw3");
                ESP_LOGI(TAG, "DeltaT: %.0ld", button3.deltaT);                
                button3.time_up = 0;
                button3.time_down = 0;
                button3.deltaT = 0;            
            }
            else // if (gpio_get_level(SW1) == BUTTON_NOT_TRIGGER && (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button.time_stamp > TIME_RESET && button.time_stamp != 0)
            {
                button3.time_up = 0;
                button3.time_down = 0;
                button3.deltaT = 0;
                button3.click_cnt = 0;
                button3.time_stamp = 0;
            }

        if (gpio_get_level(SW_LED) == BUTTON_TRIGGER)
        {
            if (button_led.time_up == 0)   button_led.time_up = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
            else                           button_led.deltaT = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button_led.time_up;
        }
        else if (gpio_get_level(SW_LED) == BUTTON_NOT_TRIGGER && button_led.time_up != 0 && button_led.deltaT > TIME_CLICK_MIN)
            {
                ESP_LOGI(TAG, "control Backlight");
                state =!state;
                // button.time_down = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
                // button.deltaT = button.time_down - button.time_up;
                ESP_LOGI(TAG, "DeltaT: %.0ld", button_led.deltaT);
                button_led.time_up = 0;
                button_led.time_down = 0;
                button_led.deltaT = 0;            
            }
            else // if (gpio_get_level(SW1) == BUTTON_NOT_TRIGGER && (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button.time_stamp > TIME_RESET && button.time_stamp != 0)
            {
                button_led.time_up = 0;
                button_led.time_down = 0;
                button_led.deltaT = 0;
                button_led.click_cnt = 0;
                button_led.time_stamp = 0;
            }
        vTaskDelay(10 / portTICK_PERIOD_MS);
    }
}
// void button_task(void *param)
// {
//     button_t button = {
//         .pin = BUTTON_CONFIG_PIN,
//         .time_down = 0,
//         .time_up = 0,
//         .deltaT = 0,
//         .click_cnt = 0,
//         .time_stamp = 0,
//     };

//     gpio_config_t config_io;
//     config_io.intr_type = GPIO_INTR_DISABLE;
//     config_io.mode = GPIO_MODE_INPUT;
//     config_io.pull_up_en = GPIO_PULLUP_ONLY;
//     config_io.pull_down_en = GPIO_PULLDOWN_DISABLE;
//     config_io.pin_bit_mask = (1ULL << button.pin);
//     gpio_config(&config_io);

//     while (1)
//     {
//         if (gpio_get_level(button.pin) == BUTTON_TRIGGER)
//         {
//             if (button.time_up == 0)
//                 button.time_up = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
//             else
//             {
//                 button.deltaT = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button.time_up;
//             }
//         }
//         else if (gpio_get_level(button.pin) == BUTTON_NOT_TRIGGER && button.time_up != 0 && button.deltaT > TIME_CLICK_MIN)
//             {
//                 button.time_down = (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS);
//                 button.deltaT = button.time_down - button.time_up;
//                 ESP_LOGI(TAG, "DeltaT: %d", button.deltaT);
//                 if (button.deltaT > TIME_HOLD)
//                 {
//                     ESP_LOGI(TAG, "Trigger Smartconfig");
//                     gateway_mode_flag = SMARTCONFIG_MODE;
//                     esp_restart();
//                 }
//                 else if (button.deltaT > TIME_CLICK_MIN && button.deltaT < TIME_CLICK_MAX)
//                     {
//                         button.click_cnt++;
//                         ESP_LOGI(TAG, "Button counter: %d", button.click_cnt);
//                         if (button.click_cnt == 5)
//                         {
//                             ESP_LOGI(TAG, "Trigger SoftAP");
//                             gateway_mode_flag = WIFI_SOFTAP_MODE;
//                             esp_restart();
//                         }
//                         else
//                         {
//                             button.time_stamp = button.time_up;
//                             button.time_up = 0;
//                             button.time_down = 0;
//                             button.deltaT = 0;
//                         }
//                     }
//             }
//             else if (gpio_get_level(button.pin) == BUTTON_NOT_TRIGGER && (uint32_t)(xTaskGetTickCount() / portTICK_PERIOD_MS) - button.time_stamp > TIME_RESET && button.time_stamp != 0)
//                 {
//                     button.time_up = 0;
//                     button.time_down = 0;
//                     button.deltaT = 0;
//                     button.click_cnt = 0;
//                     button.time_stamp = 0;
//                 }
//         vTaskDelay(10 / portTICK_PERIOD_MS);
//     }
// }
